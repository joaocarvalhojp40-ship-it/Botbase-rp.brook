// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
console.log('📦 CNV Bot Base v2.0 — estrutura modular + Components V2');
require('./src/bot');
