// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// ============================================================
//  CONFIGURAÇÕES GERAIS
//  Segredos (token e ID do servidor) NÃO ficam aqui: use o arquivo .env
//  (copie o .env.example) ou config/secrets.js (copie o secrets.example.js).
// ============================================================
const fs = require('fs');
const path = require('path');

// Lê o .env (sem dependências): linhas no formato CHAVE=valor
try {
  for (const line of fs.readFileSync(path.join(__dirname, '../.env'), 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].trim().replace(/^['"]|['"]$/g, '');
  }
} catch {}
let secrets = {};
try { secrets = require('./secrets'); } catch {}

module.exports = {
  token: process.env.TOKEN || secrets.token || '',
  guildId: process.env.GUILD_ID || secrets.guildId || '',

  // Nome do SEU roleplay. (O nome "Cidade Nova Roleplay"/CNV é marca da Hyper Squad — veja BRAND.md)
  serverName: 'Meu Roleplay',
  prefix: '$$',

  // Status do bot: "Jogando <text>" + link de convite permanente gerado pelo próprio bot
  presence: { text: 'Meu Roleplay', showInvite: true },

  money: { symbol: '$', min: 1, max: 100000 }, // limites de /enviar, /sacar, /transfer, /wage
  receiptPrefix: 'rppaymnts',                   // prefixo do ID de comprovante (ex: rppaymnts8584118)
  requireApprovedForBank: true,                 // exige cargo Aprovado p/ /saldo /enviar /sacar

  minAge: 18,
  ticketCooldownMin: 20,
  passportDate: true,                           // data no rodapé do passaporte

  // Apelido ao aprovar o personagem: "Nome do Personagem - SSN"
  nicknameSeparator: ' - ',

  // Comando $$rp (Roleplay ON)
  rp: {
    gameName: 'Brookhaven RP',
    privateServerLink: 'COLOQUE_AQUI_O_LINK_DO_SERVIDOR_PRIVADO_DO_BROOKHAVEN',
  },

  // Log de ticket em .png
  transcript: { maxMessages: 400, pageHeight: 4000, maxTotalMB: 20 },
};
