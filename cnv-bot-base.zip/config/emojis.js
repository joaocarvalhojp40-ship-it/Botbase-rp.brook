// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// ============================================================
//  EMOJIS — preencha com seus emojis personalizados quando quiser.
//  Vazio ('') = não mostra nada (visual minimalista).
//  Formato: '<:nome:123456789012345678>'  ou animado '<a:nome:123...>'
// ============================================================
module.exports = {
  ok: '',
  error: '',
  bank: '',
  cash: '',
  user: '',
  law: '',
  police: '',
  weapon: '',
  prison: '',
  ticket: '',
  call: '',
  lock: '',
  whitelist: '',
  character: '',
};
