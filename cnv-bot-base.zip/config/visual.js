// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// ============================================================
//  Visual: cores (monocromático) e banners
//
//  ⚠️ Os banners e emojis do projeto original pertencem à Hyper Squad e NÃO podem
//  ser usados (veja BRAND.md). Coloque aqui os SEUS próprios banners (links https
//  de imagem). Vazio ('') = o card é enviado sem banner.
// ============================================================
module.exports = {
  colors: { main: 0x8a8a8a, ok: 0x8a8a8a, err: 0x555555, warn: 0x6f6f6f, police: 0x6b6b6b },
  banners: {
    bank: '',
    support: '',
    passport: '',
    whitelist: '',
  },
};
