// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Alternativa ao .env. Copie este arquivo para config/secrets.js e preencha.
// config/secrets.js está no .gitignore — NUNCA envie seu token para o GitHub.
module.exports = {
  token: 'COLOQUE_O_TOKEN_DO_SEU_BOT',
  guildId: 'COLOQUE_O_ID_DO_SEU_SERVIDOR',
};
