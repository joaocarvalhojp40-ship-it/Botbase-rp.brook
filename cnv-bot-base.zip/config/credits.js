// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// ============================================================
//  ⚠️ ARQUIVO PROTEGIDO — NÃO REMOVA NEM ALTERE (veja LICENSE).
//  Estes créditos são exibidos no console e adicionados automaticamente
//  à biografia ("Sobre mim") do bot. Remover é violação da licença.
// ============================================================
module.exports = Object.freeze({
  project: 'CNV Bot Base',
  author: 'eljoaogg',
  team: 'Hyper Squad',
  github: 'https://github.com/joaocarvalhojp40-ship-it',
  contact: 'joaocarvalhojp40@gmail.com',
});
