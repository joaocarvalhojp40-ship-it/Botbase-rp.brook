// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// ============================================================
//  IDs do SEU servidor (cargos, canais, categorias)
//  Ative o Modo Desenvolvedor no Discord → botão direito → "Copiar ID".
// ============================================================
module.exports = {
  // Cargos
  police: 'COLOQUE_O_ID',          // policiais (/fine, /carrying-a-weapon, /prison)
  banker: 'COLOQUE_O_ID',          // banqueiros (/transfer, /wage, /remove) — se vazio, Moderador/Admin usam
  moderator: 'COLOQUE_O_ID',       // moderadores ($$up, $$painel, tickets)
  support: 'COLOQUE_O_ID',         // suporte (tickets e calls)
  roleWhitelist: 'COLOQUE_O_ID',   // etapa 1 (removido quando o personagem é aprovado)
  rolePersonagem: 'COLOQUE_O_ID',  // etapa 2
  roleAprovado: 'COLOQUE_O_ID',    // etapa 2

  // Canais
  policeChannel: 'COLOQUE_O_ID',   // logs da polícia
  bankChannel: 'COLOQUE_O_ID',     // único canal onde os comandos do banco funcionam
  wlPanel: 'COLOQUE_O_ID',         // painel Whitelist + Allowhitelist (também usado p/ gerar o convite permanente)
  passports: 'COLOQUE_O_ID',       // passaportes aprovados
  ticketLogs: 'COLOQUE_O_ID',      // logs de tickets (PNG)
  allowLogs: 'COLOQUE_O_ID',       // logs da Allowhitelist
  wlLogs: 'COLOQUE_O_ID',          // logs da Whitelist

  // Categorias
  ticketCategory: 'COLOQUE_O_ID',  // categoria onde os tickets são criados
};
