// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// ============================================================
//  Whitelist / Allowhitelist / Polícia
// ============================================================
module.exports = {
  // Labels de modal têm limite de 45 caracteres!
  // 9 perguntas básicas (5 na parte 1, 4 na parte 2)
  questions: [
    'O que é RDM (Random Deathmatch)?',
    'O que é VDM (Vehicle Deathmatch)?',
    'O que é Metagaming?',
    'O que é Powergaming?',
    'O que é Combat Logging?',
    'O que é Fear RP?',
    'O que é Safe Zone (Zona Segura)?',
    'Qual a diferença entre IC e OOC?',
    'O que é CK (Character Kill)?',
  ],
  // 1 pergunta de situação (parte 2)
  situation: {
    label: 'Situação: abordagem policial armada',
    placeholder: 'Você dirige e a polícia manda parar com armas apontadas. Como você age (RP)?',
  },
  races: ['Branca', 'Amarela', 'Negra', 'Parda', 'Indígena'],
  weaponTypes: ['Porte Residencial', 'Porte Civil (Concealed Carry)', 'Porte Comercial', 'Porte Policial'],
};
