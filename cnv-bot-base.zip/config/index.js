// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
module.exports = {
  ...require('./settings'),
  ids: require('./ids'),
  emojis: require('./emojis'),
  ...require('./visual'),
  ...require('./questions'),
};
