// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Registro da polícia: só o LOG aparece no canal da polícia; a confirmação é efêmera
const { ids, colors, serverName } = require('../../config');
const { card, out, sendTo, err, EPH } = require('../utils/ui');

async function log(i, title, text) {
  const sent = await sendTo(ids.policeChannel, out(card({ color: colors.police, title, text })));
  if (!sent) { await err(i, 'Não consegui enviar o registro no canal da polícia (veja os logs do bot).'); return false; }
  await i.reply({ content: `Registrado em <#${ids.policeChannel}>.`, flags: EPH });
  return true;
}

module.exports = { log };
