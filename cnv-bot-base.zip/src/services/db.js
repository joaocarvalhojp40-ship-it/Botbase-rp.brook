// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Banco de dados simples em JSON (db.json na raiz do bot)
const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, '../../db.json');
let data = { users: {}, cooldowns: {}, tx: {}, calls: {}, invite: null };
if (fs.existsSync(FILE)) {
  try { data = { ...data, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) }; }
  catch (e) {
    console.error(`❌ BUG: db.json corrompido (${e.message}). Salvei uma cópia em db.corrompido.json e comecei um banco novo.`);
    fs.renameSync(FILE, path.join(__dirname, '../../db.corrompido.json'));
  }
}

const save = () => fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
// stage: none → wl_pending → wl_ok → al_pending → done
const U = (id) => (data.users[id] ??= { stage: 'none', bank: 0, cash: 0 });
const genSSN = () => {
  const used = new Set(Object.values(data.users).map((u) => u.ssn));
  let s;
  do s = String(Math.floor(Math.random() * 900) + 100); while (used.has(s)); // SSN de 3 números (XXX)
  return s;
};

module.exports = { db: data, save, U, genSSN };
