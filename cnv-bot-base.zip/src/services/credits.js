// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Créditos obrigatórios (ver LICENSE): verificação + biografia do bot
const credits = require('../../config/credits');

const REQUIRED = { author: 'eljoaogg', team: 'Hyper Squad', github: 'joaocarvalhojp40-ship-it' };
const line = (c = credits) => `Base: ${c.project} por ${c.author} • ${c.team} | ${c.github}`;

// true = créditos íntegros. Se alterados/removidos, o bot não inicia.
function verify(c = credits) {
  const ok = c && c.author === REQUIRED.author && c.team === REQUIRED.team && String(c.github).includes(REQUIRED.github) && !!c.project;
  if (!ok) console.error('❌ LICENÇA: os créditos em config/credits.js foram removidos ou alterados. O bot não inicia sem eles — veja o arquivo LICENSE.');
  else console.log(`© ${c.project} — ${c.author} • ${c.team} (${c.github})`);
  return !!ok;
}

// Garante o crédito na biografia (descrição da aplicação, máx. 400 caracteres)
async function applyBio(client, c = credits) {
  try {
    const app = await client.application.fetch();
    const cur = app.description || '';
    if (cur.includes(c.author) && cur.includes(c.team)) return true;
    const credit = line(c);
    const room = 400 - credit.length - 2;
    const next = `${cur.slice(0, Math.max(0, room)).trimEnd()}${cur ? '\n\n' : ''}${credit}`;
    await client.application.edit({ description: next });
    console.log('📝 Crédito adicionado à biografia do bot.');
    return true;
  } catch (e) {
    console.error(`❌ BUG/CONFIG: não consegui atualizar a biografia do bot com os créditos → ${e.message}. Adicione manualmente em Developer Portal → General Information → Description: "${line(c)}"`);
    return false;
  }
}

module.exports = { verify, applyBio, line };
