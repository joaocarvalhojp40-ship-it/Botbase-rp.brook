// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Avisa (sem derrubar o bot) quais IDs de config/ids.js ainda não foram preenchidos
const { ids } = require('../../config');

function checkConfig() {
  const missing = Object.entries(ids).filter(([, v]) => !/^\d{17,20}$/.test(String(v))).map(([k]) => k);
  if (missing.length) {
    console.warn(`⚠️ CONFIG: IDs não preenchidos em config/ids.js → ${missing.join(', ')}. Os recursos que dependem deles não vão funcionar (veja DEPLOY.md).`);
  }
  return missing;
}

module.exports = { checkConfig };
