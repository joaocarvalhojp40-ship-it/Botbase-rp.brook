// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// /aprove e /reprove — o bot detecta em que etapa o jogador está
const { PermissionFlagsBits: P } = require('discord.js');
const C = require('../../config');
const { ids, banners, colors } = C;
const { save, U, genSSN } = require('./db');
const { avatarOf } = require('./roblox');
const { card, out, dm, sendTo, err, EPH } = require('../utils/ui');
const { L, ts } = require('../utils/format');

// Altera cargos e avisa no log se o bot não tiver permissão / cargo abaixo na hierarquia
const roles = async (m, op, list) => {
  try { await m.roles[op](list); return true; }
  catch (e) { console.error(`❌ BUG/CONFIG: não consegui ${op} cargos em ${m.user.tag} → ${e.message} (coloque o cargo do bot ACIMA dos cargos Whitelist/Personagem/Aprovado e dê "Gerenciar Cargos")`); return false; }
};
const nick = async (m, value) => {
  try { await m.setNickname(value, 'Allowhitelist'); return true; }
  catch (e) { console.error(`❌ BUG/CONFIG: não consegui mudar o apelido de ${m.user.tag} → ${e.message} (dono do servidor ou cargo acima do bot não pode ser alterado)`); return false; }
};

async function review(i, ok) {
  if (!i.memberPermissions.has(P.ViewAuditLog)) return err(i, 'Você precisa da permissão **Ver Registros do Servidor**.');
  const user = i.options.getUser('usuario'), reason = i.options.getString('motivo') || 'Não informado';
  const member = await i.guild.members.fetch(user.id).catch(() => null);
  if (!member) return err(i, 'Esse usuário não está no servidor.');
  const u = U(user.id);
  await i.deferReply({ flags: EPH });

  if (ok && u.stage === 'done') return err(i, 'Esse jogador já está totalmente aprovado.');
  if (ok && u.stage === 'wl_ok') return err(i, 'Esse jogador já passou na whitelist e ainda não enviou o personagem.');

  const step = ['al_pending', 'done'].includes(u.stage) ? 'allow' : 'wl';
  const title = step === 'wl' ? 'Whitelist' : 'Allowhitelist';
  const panel = `<#${ids.wlPanel}>`;
  let warn = false, dmCard, passport;
  const run = async (p) => { if (!(await p)) warn = true; };

  if (step === 'wl') {
    if (ok) { await run(roles(member, 'add', [ids.roleWhitelist])); u.stage = 'wl_ok'; }
    else { await run(roles(member, 'remove', [ids.roleWhitelist])); u.stage = 'none'; delete u.answers; }
    dmCard = ok
      ? card({ color: colors.ok, title: 'Whitelist aprovada', text: `Agora crie seu personagem (Allowhitelist) em ${panel}.`, image: banners.whitelist })
      : card({ color: colors.err, title: 'Whitelist reprovada', text: L(`**Motivo:** ${reason}`, '', `Você pode tentar novamente em ${panel}.`), image: banners.whitelist });
  } else if (ok) {
    u.stage = 'done'; u.ssn = genSSN();
    const c = u.char;
    await run(roles(member, 'add', [ids.rolePersonagem, ids.roleAprovado]));
    await run(roles(member, 'remove', [ids.roleWhitelist])); // etapa anterior sai
    const suffix = `${C.nicknameSeparator}${u.ssn}`;
    await run(nick(member, c.nome.slice(0, 32 - suffix.length) + suffix)); // "Nome do Personagem - SSN"
    c.avatar = (await avatarOf(c.robloxId).catch(() => null)) || c.avatar; // foto do RG = avatar do Roblox

    passport = card({
      title: `PERSONAGEM | ${C.serverName.toUpperCase()}`, thumb: c.avatar, image: banners.passport,
      text: L(`**Nome:** ${c.nome}`, `**Idade:** ${c.idade}`, `**SSN:** ${u.ssn}`, `**Nacionalidade:** ${c.nacionalidade}`),
      footer: `processo concluído por "${i.user.username}"${C.passportDate ? ` • ${ts()}` : ''}`,
    });
    await sendTo(ids.passports, out(passport));
    dmCard = card({ color: colors.ok, title: 'Personagem aprovado', text: `Seu passaporte foi emitido em <#${ids.passports}>. Bom RP!`, image: banners.passport });
  } else {
    await run(roles(member, 'remove', [ids.rolePersonagem, ids.roleAprovado]));
    await run(roles(member, 'add', [ids.roleWhitelist])); // volta para a etapa anterior
    await run(nick(member, null));
    u.stage = 'wl_ok'; delete u.char; delete u.ssn;
    dmCard = card({ color: colors.err, title: 'Personagem reprovado', text: L(`**Motivo:** ${reason}`, '', `Você pode criar outro personagem em ${panel}.`), image: banners.passport });
  }
  save();
  await dm(user, dmCard);
  if (passport) await dm(user, passport);

  await sendTo(step === 'wl' ? ids.wlLogs : ids.allowLogs, out(card({
    color: ok ? colors.ok : colors.err, title: `${title} ${ok ? 'aprovada' : 'reprovada'}`,
    text: L(`**Jogador:** ${user} (${user.id})`, `**Staff:** ${i.user}`, ok ? false : `**Motivo:** ${reason}`),
  })));
  return i.editReply(`${user} foi **${ok ? 'aprovado' : 'reprovado'}** na etapa **${title}**.${warn ? '\n⚠️ Não consegui alterar cargos/apelido: o cargo do bot precisa ficar **acima** deles e ter *Gerenciar Cargos* e *Gerenciar Apelidos*.' : ''}`);
}

module.exports = { review };
