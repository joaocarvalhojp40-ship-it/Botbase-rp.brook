// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Convite permanente (nunca expira, usos ilimitados) gerado e reaproveitado pelo bot
const { ids } = require('../../config');
const { db, save } = require('./db');

const url = (code) => `https://discord.gg/${code}`;

async function ensureInvite(client) {
  if (db.invite) {
    const valid = await client.fetchInvite(db.invite).catch(() => null);
    if (valid) return url(db.invite);
  }
  try {
    const ch = await client.channels.fetch(ids.wlPanel);
    const inv = await ch.createInvite({ maxAge: 0, maxUses: 0, unique: true, reason: 'Convite permanente do bot' });
    db.invite = inv.code; save();
    return url(inv.code);
  } catch (e) {
    console.error(`❌ BUG/CONFIG: não consegui criar o convite permanente → ${e.message} (o bot precisa da permissão "Criar convite" no canal ${ids.wlPanel})`);
    return null;
  }
}

module.exports = { ensureInvite };
