// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Economia: comprovantes (IDs de transação) e cards do banco
const C = require('../../config');
const { db, save } = require('./db');
const { card } = require('../utils/ui');
const { money, L } = require('../utils/format');

const TYPES = { payment: 'Pagamento', withdraw: 'Saque', wage: 'Salário', remove: 'Remoção', fine: 'Multa' };

const newId = () => {
  let id;
  do id = C.receiptPrefix + String(Math.floor(1000000 + Math.random() * 9000000)); while (db.tx[id]);
  return id;
};
// tx: { type, from, to, value, reason?, by, id? }
const record = (tx) => {
  const t = { at: Date.now(), ...tx, id: tx.id || newId() };
  db.tx[t.id] = t;
  save();
  return t;
};

const k = (name, v) => `**${name}:** ${v}`;
const receiptCard = (title, lines) => card({ title: `${title} - ${C.serverName.toUpperCase()}`, text: L(...lines), image: C.banners.bank });
const receiptLine = (tx) => k('Comprovante', `\`${tx.id}\``);

// Igual ao modelo "PAGAMENTO" do banco
const paymentCard = (tx) =>
  receiptCard('PAGAMENTO', [k('Efetuado por', `<@${tx.from}>`), k('Destinado para', `<@${tx.to}>`), '', k('Valor', money(tx.value)), receiptLine(tx)]);

module.exports = { TYPES, newId, record, k, receiptCard, receiptLine, paymentCard };
