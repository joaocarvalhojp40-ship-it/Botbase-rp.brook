// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Log do ticket em .png (avatar + nome, imagens, emojis e figurinhas). Fallback: .txt
const path = require('path');
const { AttachmentBuilder } = require('discord.js');
const C = require('../../config');

let lib = null;
try {
  lib = require('@napi-rs/canvas');
  const dir = path.join(__dirname, '../../assets/fonts');
  const reg = (f, name) => { try { lib.GlobalFonts.registerFromPath(path.join(dir, f), name); } catch {} };
  reg('Inter-Regular.otf', 'TInter'); reg('Inter-Bold.otf', 'TInterBold'); reg('DejaVuSans.ttf', 'TDejaVu');
} catch (e) {
  console.error(`❌ BUG/CONFIG: @napi-rs/canvas indisponível (${e.message}) — o log do ticket sairá em .txt.`);
}

const REG = 'TInter, TDejaVu, sans-serif', BOLD = 'TInterBold, TDejaVu, sans-serif';
const W = 820, PAD = 20, TX = 74, TW = W - TX - PAD, LH = 21, SZ = 15, EW = 22;
const BG = '#2b2d31', TEXT = '#dbdee1', NAME = '#f2f3f5', MUTED = '#949ba4';

const fmt = (ms) => new Date(ms).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo', dateStyle: 'short', timeStyle: 'short' });

// ── emojis (unicode via Twemoji, personalizados via CDN do Discord) ──
const EMOJI_RE = /<a?:\w+:(\d+)>|(\p{Extended_Pictographic}(?:\uFE0F|\u200D\p{Extended_Pictographic}|[\u{1F3FB}-\u{1F3FF}])*|[\u{1F1E6}-\u{1F1FF}]{2})/gu;
const twemoji = (s) => {
  const cps = [...s].map((c) => c.codePointAt(0).toString(16));
  const list = cps.includes('200d') ? cps : cps.filter((c) => c !== 'fe0f');
  return `https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/${list.join('-')}.png`;
};
function tokenize(text) {
  const res = []; let last = 0;
  for (const m of text.matchAll(EMOJI_RE)) {
    if (m.index > last) res.push({ k: 't', s: text.slice(last, m.index) });
    res.push({ k: 'e', url: m[1] ? `https://cdn.discordapp.com/emojis/${m[1]}.png?size=64` : twemoji(m[0]) });
    last = m.index + m[0].length;
  }
  if (last < text.length) res.push({ k: 't', s: text.slice(last) });
  return res;
}

// ── quebra de linha com emojis inline ──
function layout(ctx, text, maxW) {
  const lines = [[]]; let x = 0;
  const nl = () => { lines.push([]); x = 0; };
  const put = (it) => { lines[lines.length - 1].push(it); x += it.w; };
  text.split('\n').forEach((para, idx) => {
    if (idx) nl();
    for (const tk of tokenize(para)) {
      if (tk.k === 'e') { if (x + EW > maxW && x > 0) nl(); put({ k: 'e', url: tk.url, w: EW }); continue; }
      for (const part of tk.s.split(/(\s+)/)) {
        if (!part) continue;
        const space = /^\s+$/.test(part);
        const w = ctx.measureText(part).width;
        if (x + w > maxW && x > 0) { nl(); if (space) continue; }
        if (w > maxW) { // palavra maior que a linha → quebra por caractere
          let buf = '';
          for (const ch of part) {
            if (buf && ctx.measureText(buf + ch).width > maxW) { put({ k: 't', s: buf, w: ctx.measureText(buf).width }); nl(); buf = ch; }
            else buf += ch;
          }
          if (buf) put({ k: 't', s: buf, w: ctx.measureText(buf).width });
          continue;
        }
        put({ k: 't', s: part, w });
      }
    }
  });
  return lines;
}

// ── mensagens ──
async function fetchAll(channel, max) {
  const all = []; let before;
  while (all.length < max) {
    const batch = await channel.messages.fetch({ limit: 100, ...(before ? { before } : {}) });
    if (!batch.size) break;
    all.push(...batch.values());
    before = batch.last().id;
    if (batch.size < 100) break;
  }
  const truncated = all.length >= max;
  return { msgs: all.slice(0, max).reverse(), truncated }; // mais antigas primeiro
}

const v2text = (comps = []) => comps.flatMap((c) => [
  typeof c.content === 'string' ? c.content : null,
  ...v2text(c.components || []),
  ...(c.accessory ? v2text([c.accessory]) : []),
]).filter(Boolean);
const clean = (s) => s.replace(/^-#\s*/gm, '').replace(/^#+\s*/gm, '').replace(/\*\*|`/g, '');

function toItem(m) {
  let text = m.cleanContent || '';
  try { const v = v2text(m.components); if (v.length) text = clean(v.join('\n')); } catch {}
  for (const e of m.embeds || []) { const t = [e.title, e.description].filter(Boolean).join(' — '); if (t) text += `${text ? '\n' : ''}${t}`; }
  const imgs = [], notes = [];
  for (const a of m.attachments.values()) (a.contentType?.startsWith('image/') ? imgs : notes).push(a.contentType?.startsWith('image/') ? a.url : `[arquivo] ${a.name}`);
  const stickers = [...m.stickers.values()].map((s) => ({ name: s.name, url: s.url, lottie: s.format === 3 }));
  if (notes.length) text += `${text ? '\n' : ''}${notes.join('\n')}`;
  if (!text && !imgs.length && !stickers.length) return null;
  return {
    name: m.member?.displayName || m.author.globalName || m.author.username,
    time: fmt(m.createdTimestamp), ts: m.createdTimestamp,
    avatar: m.author.displayAvatarURL({ extension: 'png', size: 64 }), text, imgs, stickers,
  };
}

// ── renderização ──
async function renderPages(items) {
  const cache = new Map();
  const load = (url) => {
    if (!cache.has(url)) cache.set(url, (async () => {
      try {
        const r = await fetch(url, { signal: AbortSignal.timeout(10000) });
        if (!r.ok) return null;
        const buf = Buffer.from(await r.arrayBuffer());
        return buf.length > 8e6 ? null : await lib.loadImage(buf);
      } catch { return null; }
    })());
    return cache.get(url);
  };

  const mctx = lib.createCanvas(10, 10).getContext('2d');
  mctx.font = `${SZ}px ${REG}`;

  for (let n = 0; n < items.length; n += 10) { // carrega em lotes de 10 mensagens
    await Promise.all(items.slice(n, n + 10).map(async (it) => {
      it.lines = it.text ? layout(mctx, it.text, TW) : [];
      const urls = [it.avatar, ...it.imgs, ...it.stickers.filter((s) => !s.lottie).map((s) => s.url),
        ...it.lines.flat().filter((p) => p.k === 'e').map((p) => p.url)];
      await Promise.all(urls.map(load));
      // mídia já carregada → calcula tamanhos
      it.media = [];
      for (const u of it.imgs) {
        const im = cache.get(u) && await cache.get(u);
        if (!im) { it.lines.push([{ k: 't', s: '[imagem indisponível]', w: mctx.measureText('[imagem indisponível]').width }]); continue; }
        const sc = Math.min(1, 420 / im.width, 320 / im.height);
        it.media.push({ im, w: Math.round(im.width * sc), h: Math.round(im.height * sc) });
      }
      for (const s of it.stickers) {
        const im = !s.lottie && await cache.get(s.url);
        if (!im) { const t = `[figurinha: ${s.name}]`; it.lines.push([{ k: 't', s: t, w: mctx.measureText(t).width }]); continue; }
        it.media.push({ im, w: 128, h: 128 });
      }
      it.h = 8 + 22 + it.lines.length * LH + it.media.reduce((a, m) => a + m.h + 8, 0) + 12;
      it.avatarImg = await cache.get(it.avatar);
    }));
  }

  // paginação
  const pages = []; let cur = [], h = 0;
  for (const it of items) {
    if (cur.length && h + it.h > C.transcript.pageHeight) { pages.push(cur); cur = []; h = 0; }
    cur.push(it); h += it.h;
  }
  if (cur.length) pages.push(cur);

  const drawEmoji = async (ctx, url, x, y) => { const im = await cache.get(url); if (im) ctx.drawImage(im, x, y - 1, 20, 20); };
  return { pages, cache, drawEmoji };
}

async function toPngs(items, title) {
  const { pages, cache } = await renderPages(items);
  const bufs = [];
  for (let p = 0; p < pages.length; p++) {
    const headH = p === 0 ? 74 : 34;
    const total = headH + pages[p].reduce((a, it) => a + it.h, 0) + 16;
    const canvas = lib.createCanvas(W, total), ctx = canvas.getContext('2d');
    ctx.fillStyle = BG; ctx.fillRect(0, 0, W, total);
    ctx.textBaseline = 'top';
    if (p === 0) {
      ctx.fillStyle = NAME; ctx.font = `20px ${BOLD}`; ctx.fillText(title, PAD, 18);
      ctx.fillStyle = MUTED; ctx.font = `13px ${REG}`; ctx.fillText(`${items.length} mensagens • ${fmt(Date.now())}`, PAD, 46);
    } else { ctx.fillStyle = MUTED; ctx.font = `13px ${REG}`; ctx.fillText(`${title} — página ${p + 1}/${pages.length}`, PAD, 10); }
    let y = headH;
    for (const it of pages[p]) {
      const ay = y + 8;
      if (it.avatarImg) { ctx.save(); ctx.beginPath(); ctx.arc(PAD + 20, ay + 20, 20, 0, Math.PI * 2); ctx.closePath(); ctx.clip(); ctx.drawImage(it.avatarImg, PAD, ay, 40, 40); ctx.restore(); }
      else { ctx.fillStyle = '#4e5058'; ctx.beginPath(); ctx.arc(PAD + 20, ay + 20, 20, 0, Math.PI * 2); ctx.fill(); }
      ctx.font = `16px ${BOLD}`; ctx.fillStyle = NAME; ctx.fillText(it.name, TX, y + 8);
      const nw = ctx.measureText(it.name).width;
      ctx.font = `12px ${REG}`; ctx.fillStyle = MUTED; ctx.fillText(it.time, TX + nw + 10, y + 11);
      let cy = y + 8 + 22;
      ctx.font = `${SZ}px ${REG}`;
      for (const line of it.lines) {
        let x = TX;
        for (const part of line) {
          if (part.k === 't') { ctx.fillStyle = TEXT; ctx.fillText(part.s, x, cy); }
          else { const im = await cache.get(part.url); if (im) ctx.drawImage(im, x, cy - 1, 20, 20); }
          x += part.w;
        }
        cy += LH;
      }
      for (const m of it.media) { ctx.drawImage(m.im, TX, cy, m.w, m.h); cy += m.h + 8; }
      y += it.h;
    }
    bufs.push(await canvas.encode('png'));
  }
  return bufs;
}

const toTxt = (msgs) => Buffer.from(msgs.map((m) => {
  const it = toItem(m); if (!it) return null;
  return `[${it.time}] ${it.name}: ${it.text}${it.imgs.length ? `\n  imagens: ${it.imgs.join(' ')}` : ''}${it.stickers.length ? `\n  figurinhas: ${it.stickers.map((s) => s.name).join(', ')}` : ''}`;
}).filter(Boolean).join('\n'), 'utf8');

/** Gera o log do ticket. Retorna { files, count, truncated, kind: 'png' | 'txt' } */
async function transcript(channel) {
  const { msgs, truncated } = await fetchAll(channel, C.transcript.maxMessages);
  const slug = channel.name.replace(/[^a-z0-9-]/gi, '').slice(0, 40) || 'ticket';
  const items = msgs.map(toItem).filter(Boolean);
  const txt = () => ({ files: [new AttachmentBuilder(toTxt(msgs), { name: `${slug}.txt` })], count: items.length, truncated, kind: 'txt' });
  if (!lib) return txt();
  try {
    const bufs = await toPngs(items, `#${channel.name}`);
    const files = []; let size = 0;
    for (let n = 0; n < bufs.length && files.length < 10; n++) {
      size += bufs[n].length;
      if (size > C.transcript.maxTotalMB * 1024 * 1024) break;
      files.push(new AttachmentBuilder(bufs[n], { name: `${slug}-${n + 1}.png` }));
    }
    return { files, count: items.length, truncated: truncated || files.length < bufs.length, kind: 'png' };
  } catch (e) {
    console.error('❌ BUG: falha ao gerar o PNG do ticket → fallback .txt:', e);
    return txt();
  }
}

module.exports = { transcript, layout, tokenize };
