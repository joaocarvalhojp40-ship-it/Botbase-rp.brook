// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// API pública do Roblox — foto do RG (avatar do jogador)
const rbx = async (url, opt = {}) => {
  const r = await fetch(url, { ...opt, signal: AbortSignal.timeout(8000) });
  if (!r.ok) throw new Error(`Roblox API HTTP ${r.status}`);
  return r.json();
};

const avatarOf = async (id) =>
  (await rbx(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${id}&size=420x420&format=Png&isCircular=false`)).data?.[0]?.imageUrl || null;

const lookup = async (username) => {
  const j = await rbx('https://users.roblox.com/v1/usernames/users', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usernames: [username], excludeBannedUsers: true }),
  });
  const u = j.data?.[0];
  return u ? { id: u.id, name: u.name, avatar: await avatarOf(u.id) } : null;
};

module.exports = { lookup, avatarOf };
