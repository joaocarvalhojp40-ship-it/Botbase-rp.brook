// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const C = require('../config');
const client = require('./client');
const credits = require('./services/credits');

if (!credits.verify()) process.exit(1); // créditos obrigatórios (LICENSE)

// Token e guildId: vêm do .env ou de config/secrets.js (veja DEPLOY.md)
const TOKEN = String(C.token || '').replace(/["'\s]/g, '').replace(/^Bot/i, '');
if (!/^[\w-]{20,}\.[\w-]{4,}\.[\w-]{20,}$/.test(TOKEN)) {
  console.error('❌ CONFIG: token ausente ou inválido. Defina TOKEN no arquivo .env (veja .env.example) ou em config/secrets.js. Guia: DEPLOY.md');
  process.exit(1);
}
if (!/^\d{17,20}$/.test(String(C.guildId || ''))) {
  console.error('❌ CONFIG: GUILD_ID ausente ou inválido. Coloque o ID numérico do seu servidor no .env ou em config/secrets.js. Guia: DEPLOY.md');
  process.exit(1);
}
let botId = '?';
try { botId = Buffer.from(TOKEN.split('.')[0], 'base64').toString(); } catch {}
console.log(`🔑 Token carregado — bot ID ${botId} — final ...${TOKEN.slice(-4)}`);

require('./loader')(client);

process.on('unhandledRejection', (e) => console.error('Erro não tratado:', e?.message || e));

client.login(TOKEN).catch((e) => {
  if (e.code === 'DisallowedIntents') console.error('❌ BUG/CONFIG: "Message Content Intent" desligado. Developer Portal → Bot → ligue MESSAGE CONTENT INTENT e reinicie.');
  else if (e.code === 'TokenInvalid' || /token/i.test(e.message)) console.error(`❌ BUG/CONFIG: o Discord recusou o token (bot ID ${botId}, final ...${TOKEN.slice(-4)}). Gere um novo em Developer Portal → Bot → Reset Token.`);
  else console.error('❌ Falha no login:', e.message);
  process.exit(1);
});
