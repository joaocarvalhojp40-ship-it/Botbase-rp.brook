// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const C = require('../../config');

const money = (n) => `${C.money.symbol}${n.toLocaleString('en-US')}`;
const L = (...l) => l.filter((x) => x !== false && x != null).join('\n'); // junta linhas (ignora false/null)
const ts = (ms = Date.now()) => `<t:${Math.floor(ms / 1000)}:f>`;

module.exports = { money, L, ts };
