// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Componentes V2 minimalistas + helpers de interface
const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle,
  ContainerBuilder, TextDisplayBuilder, SectionBuilder, ThumbnailBuilder,
  MediaGalleryBuilder, MediaGalleryItemBuilder, SeparatorBuilder, SeparatorSpacingSize, FileBuilder, MessageFlags,
} = require('discord.js');
const C = require('../../config');
const client = require('../client');
const { colors, emojis: E } = C;

const EPH = MessageFlags.Ephemeral;
const V2 = MessageFlags.IsComponentsV2;

const em = (k) => (E[k] ? `${E[k]} ` : ''); // emoji + espaço (vazio se não configurado)
const T = (s) => new TextDisplayBuilder().setContent(s);

/**
 * Card Components V2 (container cinza):
 * título + texto [+ thumbnail] [+ imagens] [+ linhas de botões/selects] [+ rodapé]
 */
function card({ color = colors.main, title, text, thumb, image, images, files, rows, footer }) {
  const c = new ContainerBuilder().setAccentColor(color);
  const body = (title ? `## ${title}\n` : '') + (text || '\u200e');
  if (thumb) c.addSectionComponents(new SectionBuilder().addTextDisplayComponents(T(body)).setThumbnailAccessory(new ThumbnailBuilder().setURL(thumb)));
  else c.addTextDisplayComponents(T(body));

  const imgs = [].concat(image || [], images || []).slice(0, 10);
  if (imgs.length) c.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(...imgs.map((u) => new MediaGalleryItemBuilder().setURL(u))));

  for (const f of [].concat(files || [])) c.addFileComponents(new FileBuilder().setURL(f));

  const rs = [].concat(rows || []);
  if (rs.length) c.addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)).addActionRowComponents(...rs);

  if (footer) c.addTextDisplayComponents(T(`-# ${footer}`));
  return c;
}
const out = (c, eph = false) => ({ components: [c], flags: eph ? V2 | EPH : V2 });

const btn = (id, label, style = ButtonStyle.Secondary, emojiKey) => {
  const b = new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style);
  if (emojiKey && E[emojiKey]) b.setEmoji(E[emojiKey]);
  return b;
};
const linkBtn = (label, url) => new ButtonBuilder().setLabel(label).setStyle(ButtonStyle.Link).setURL(url);
const row = (...c) => new ActionRowBuilder().addComponents(...c);

const modal = (id, title, fields) =>
  new ModalBuilder().setCustomId(id).setTitle(title).addComponents(
    fields.map((f) => {
      const t = new TextInputBuilder().setCustomId(f.id).setLabel(f.label)
        .setStyle(f.long ? TextInputStyle.Paragraph : TextInputStyle.Short).setRequired(true).setMaxLength(f.max || 250);
      if (f.ph) t.setPlaceholder(f.ph);
      return row(t);
    }),
  );
const answersOf = (i) => Object.fromEntries([...i.fields.fields.values()].map((f) => [f.customId, f.value]));

// Respostas simples (texto) — funcionam em interações respondidas ou não
const err = (i, m) => {
  const p = { content: `${em('error')}${m}` };
  return i.deferred || i.replied ? i.editReply(p) : i.reply({ ...p, flags: EPH });
};
const okMsg = (i, m) => {
  const p = { content: `${em('ok')}${m}` };
  return i.deferred || i.replied ? i.editReply(p) : i.reply({ ...p, flags: EPH });
};

const dm = (user, c) => user.send(out(c)).catch(() => {});
const sendTo = async (id, payload) => {
  try { return await (await client.channels.fetch(id)).send(payload); }
  catch (e) { console.error(`❌ BUG/CONFIG: não consegui enviar no canal ${id} → ${e.message} (verifique o ID e as permissões do bot nesse canal)`); }
};

module.exports = { EPH, V2, em, T, card, out, btn, linkBtn, row, modal, answersOf, err, okMsg, dm, sendTo };
