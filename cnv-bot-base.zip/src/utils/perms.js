// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { PermissionFlagsBits: P } = require('discord.js');
const { ids } = require('../../config');

const has = (i, role) => i.member.roles.cache.has(role);
const isStaff = (member) => member.roles.cache.has(ids.moderator) || member.roles.cache.has(ids.support);
// Se o cargo de banqueiro ainda não foi configurado, Moderador/Admin podem usar (evita bloquear todo mundo)
const isBanker = (i) =>
  /^\d+$/.test(ids.banker) ? has(i, ids.banker) : has(i, ids.moderator) || i.memberPermissions.has(P.Administrator);

const isMod = (member) => member.roles.cache.has(ids.moderator) || member.permissions.has(P.Administrator);

module.exports = { has, isStaff, isMod, isBanker };
