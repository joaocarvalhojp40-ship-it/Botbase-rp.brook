// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Atalhos para montar opções de slash command
const C = require('../../config');
const { money } = require('./format');

const user = (n, d, req = true) => (o) => o.setName(n).setDescription(d).setRequired(req);
const str = (n, d, req = true) => (o) => o.setName(n).setDescription(d).setRequired(req);
const int = (n, d, min, max) => (o) => {
  o.setName(n).setDescription(d).setRequired(true).setMinValue(min);
  if (max) o.setMaxValue(max);
  return o;
};
const value = int('valor', `Valor (${money(C.money.min)} a ${money(C.money.max)})`, C.money.min, C.money.max);

module.exports = { user, str, int, value };
