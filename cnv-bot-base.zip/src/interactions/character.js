// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Allowhitelist: criação do personagem (nome, idade ≥ 18, nacionalidade, raça + usuário do Roblox p/ foto do RG)
const C = require('../../config');
const { ids, banners, colors } = C;
const { U, save } = require('../services/db');
const roblox = require('../services/roblox');
const { modal, answersOf, err, okMsg, dm, sendTo, card, out, EPH } = require('../utils/ui');
const { L } = require('../utils/format');

module.exports = [
  {
    id: 'al_start',
    run: async (i) => {
      const u = U(i.user.id);
      if (u.stage === 'none' || u.stage === 'wl_pending') return err(i, 'Você precisa ser aprovado na **Whitelist** primeiro.');
      if (u.stage === 'al_pending') return err(i, 'Seu personagem já está em análise.');
      if (u.stage === 'done') return err(i, 'Você já tem um personagem aprovado.');
      return i.showModal(modal('al', 'Criar personagem', [
        { id: 'nome', label: 'Nome completo', max: 50 },
        { id: 'idade', label: `Idade (mínimo ${C.minAge})`, max: 3 },
        { id: 'nacionalidade', label: 'Nacionalidade', ph: 'Ex: Estados Unidos', max: 40 },
        { id: 'raca', label: 'Raça', ph: C.races.join(', '), max: 20 },
        { id: 'roblox', label: 'Seu usuário do Roblox (foto do RG)', ph: 'Ex: Builderman', max: 20 },
      ]));
    },
  },
  {
    id: 'al',
    run: async (i) => {
      await i.deferReply({ flags: EPH }); // a consulta ao Roblox pode demorar
      const u = U(i.user.id), a = answersOf(i);
      if (u.stage !== 'wl_ok') return err(i, 'Você não pode criar personagem agora.');

      const age = /^\d{1,2}$/.test(a.idade.trim()) ? Number(a.idade.trim()) : NaN;
      if (!Number.isInteger(age) || age < C.minAge || age > 99) return err(i, `A idade deve ser um número entre ${C.minAge} e 99 (mínimo ${C.minAge} anos).`);
      const raca = C.races.find((r) => r.toLowerCase() === a.raca.trim().toLowerCase());
      if (!raca) return err(i, `Raça inválida. Opções: ${C.races.join(', ')}.`);
      const name = a.roblox.trim();
      if (!/^[A-Za-z0-9_]{3,20}$/.test(name)) return err(i, 'Usuário do Roblox inválido (3 a 20 letras, números ou _).');

      let rb;
      try { rb = await roblox.lookup(name); }
      catch (e) { console.error(`❌ BUG/CONFIG: falha na API do Roblox → ${e.message}`); return err(i, 'Não consegui consultar a API do Roblox agora. Tente novamente em instantes.'); }
      if (!rb) return err(i, `Usuário **${name}** não encontrado no Roblox.`);
      if (!rb.avatar) return err(i, 'Não consegui carregar o avatar desse usuário. Tente novamente em instantes.');

      const c = u.char = { nome: a.nome.trim(), idade: age, nacionalidade: a.nacionalidade.trim(), raca, roblox: rb.name, robloxId: rb.id, avatar: rb.avatar };
      u.stage = 'al_pending'; save();

      await sendTo(ids.allowLogs, out(card({
        color: colors.warn, title: `Novo personagem — ${i.user.username}`, thumb: c.avatar,
        text: L(`${i.user} (${i.user.id})`, '', `**Nome:** ${c.nome}`, `**Idade:** ${c.idade}`, `**Nacionalidade:** ${c.nacionalidade}`, `**Raça:** ${c.raca}`, `**Roblox:** ${c.roblox} (${c.robloxId})`, '', 'Use /aprove ou /reprove.'),
      })));
      await dm(i.user, card({ color: colors.warn, title: 'Personagem enviado', thumb: c.avatar, text: 'Seu personagem está em análise — você será avisado por aqui.', image: banners.passport }));
      return okMsg(i, 'Personagem enviado para análise. Acompanhe pela sua DM.');
    },
  },
];
