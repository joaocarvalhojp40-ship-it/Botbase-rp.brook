// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Tickets: abrir, criar call (voz privada), gerenciar acesso da call e fechar com log em .png
const { ChannelType, PermissionFlagsBits: P, UserSelectMenuBuilder } = require('discord.js');
const C = require('../../config');
const { ids, banners, colors } = C;
const { db, save } = require('../services/db');
const { transcript } = require('../services/transcript');
const { isStaff } = require('../utils/perms');
const { btn, row, err, okMsg, card, out, sendTo, EPH, em } = require('../utils/ui');
const { L } = require('../utils/format');

const ACCESS = [P.ViewChannel, P.Connect, P.Speak, P.SendMessages, P.ReadMessageHistory, P.AttachFiles];
const ACCESS_EDIT = { ViewChannel: true, Connect: true, Speak: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true };
const byVoice = (voiceId) => Object.entries(db.calls).find(([, c]) => c.voice === voiceId);
const canManage = (i, owner) => i.user.id === owner || isStaff(i.member);

module.exports = [
  {
    id: 'ticket_open',
    run: async (i) => {
      const open = i.guild.channels.cache.find((c) => c.parentId === ids.ticketCategory && c.topic === i.user.id);
      if (open) return err(i, `Você já possui um ticket aberto: ${open}`);
      const cd = db.cooldowns[i.user.id] || 0;
      if (Date.now() < cd) return err(i, `Aguarde <t:${Math.ceil(cd / 1000)}:R> para abrir outro ticket.`);
      await i.deferReply({ flags: EPH });
      let ch;
      try {
        ch = await i.guild.channels.create({
          name: `ticket-${i.user.username}`.slice(0, 90), type: ChannelType.GuildText, parent: ids.ticketCategory, topic: i.user.id,
          permissionOverwrites: [
            { id: i.guild.id, deny: [P.ViewChannel] },
            { id: i.user.id, allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.AttachFiles] },
            { id: ids.support, allow: [P.ViewChannel, P.SendMessages, P.ReadMessageHistory, P.ManageMessages] },
            { id: i.client.user.id, allow: [P.ViewChannel, P.SendMessages, P.ManageChannels, P.MentionEveryone, P.ReadMessageHistory] },
          ],
        });
      } catch (e) {
        console.error(`❌ BUG/CONFIG: não consegui criar o ticket → ${e.message} (verifique o ID da categoria de suporte e a permissão "Gerenciar Canais" do bot)`);
        return err(i, 'Não consegui criar o ticket. Avise a equipe.');
      }
      db.cooldowns[i.user.id] = Date.now() + C.ticketCooldownMin * 60000; save();
      await ch.send({ content: `@here ${i.user}` }); // mensagem simples para garantir a menção
      await ch.send(out(card({
        title: 'Ticket aberto', image: banners.support,
        text: L(`Olá ${i.user}, sua solicitação foi aberta e a equipe de suporte responderá em breve.`, '',
          'Descreva seu problema com detalhes e anexe provas, se houver.',
          '**Respeite** a equipe e os demais — desrespeito resulta em punição.'),
        rows: row(btn('call_create', 'Criar call', undefined, 'call'), btn('ticket_close', 'Fechar ticket', undefined, 'lock')),
      })));
      await sendTo(ids.ticketLogs, out(card({ color: colors.ok, title: 'Ticket aberto', text: L(`**Usuário:** ${i.user}`, `**Canal:** ${ch}`) })));
      return okMsg(i, `Ticket criado: ${ch}`);
    },
  },

  {
    id: 'call_create',
    run: async (i) => {
      const ch = i.channel, owner = ch.topic;
      if (!canManage(i, owner)) return err(i, 'Apenas o dono do ticket ou a equipe pode criar a call.');
      const existing = db.calls[ch.id] && i.guild.channels.cache.get(db.calls[ch.id].voice);
      if (existing) return err(i, `Já existe uma call para este ticket: ${existing}`);
      await i.deferReply({ flags: EPH });
      let voice;
      try {
        voice = await i.guild.channels.create({
          name: `call-${ch.name.replace(/^ticket-/, '')}`.slice(0, 90), type: ChannelType.GuildVoice, // sem categoria
          permissionOverwrites: [
            { id: i.guild.id, deny: [P.ViewChannel, P.Connect] },
            { id: owner, allow: ACCESS },
            { id: ids.moderator, allow: ACCESS },
            { id: ids.support, allow: ACCESS },
            { id: i.client.user.id, allow: [...ACCESS, P.ManageChannels, P.ManageRoles] },
          ],
        });
        await voice.send(out(card({
          title: 'Call do ticket',
          text: L(`**Responsável:** <@${owner}>`, '', 'Use os menus abaixo para adicionar ou remover o acesso de usuários a esta call.'),
          rows: [
            row(new UserSelectMenuBuilder().setCustomId('call_add').setPlaceholder('Adicionar usuário').setMinValues(1).setMaxValues(1)),
            row(new UserSelectMenuBuilder().setCustomId('call_remove').setPlaceholder('Remover usuário').setMinValues(1).setMaxValues(1)),
            row(btn('call_close', 'Encerrar call')),
          ],
        })));
      } catch (e) {
        console.error(`❌ BUG/CONFIG: não consegui criar a call → ${e.message} (o bot precisa de "Gerenciar Canais" e "Gerenciar Permissões")`);
        if (voice) voice.delete().catch(() => {});
        return err(i, 'Não consegui criar a call. Avise a equipe.');
      }
      db.calls[ch.id] = { voice: voice.id, owner }; save();
      return okMsg(i, `Call criada: ${voice}`);
    },
  },

  {
    id: 'call_add',
    run: async (i) => {
      const rec = byVoice(i.channelId);
      if (!rec) return err(i, 'Esta call não está registrada.');
      if (!canManage(i, rec[1].owner)) return err(i, 'Apenas o dono do ticket ou a equipe pode gerenciar a call.');
      const target = i.users.first();
      if (target.bot) return err(i, 'Não é possível adicionar bots.');
      await i.channel.permissionOverwrites.edit(target.id, ACCESS_EDIT);
      return okMsg(i, `${target} agora tem acesso a esta call.`);
    },
  },
  {
    id: 'call_remove',
    run: async (i) => {
      const rec = byVoice(i.channelId);
      if (!rec) return err(i, 'Esta call não está registrada.');
      if (!canManage(i, rec[1].owner)) return err(i, 'Apenas o dono do ticket ou a equipe pode gerenciar a call.');
      const target = i.users.first();
      if (target.id === rec[1].owner) return err(i, 'Não é possível remover o dono do ticket.');
      await i.channel.permissionOverwrites.delete(target.id);
      return okMsg(i, `O acesso de ${target} foi removido.`);
    },
  },
  {
    id: 'call_close',
    run: async (i) => {
      const rec = byVoice(i.channelId);
      if (!rec) return err(i, 'Esta call não está registrada.');
      if (!canManage(i, rec[1].owner)) return err(i, 'Apenas o dono do ticket ou a equipe pode encerrar a call.');
      await i.reply({ content: 'Encerrando a call...', flags: EPH });
      delete db.calls[rec[0]]; save();
      await i.channel.delete().catch(() => {});
    },
  },

  {
    id: 'ticket_close',
    run: async (i) => {
      const ch = i.channel;
      if (ch.topic !== i.user.id && !isStaff(i.member)) return err(i, 'Sem permissão para fechar este ticket.');
      await i.reply('Gerando o log e fechando o ticket...');

      let t;
      try { t = await transcript(ch); }
      catch (e) { console.error('❌ BUG: falha ao gerar o log do ticket →', e); return i.editReply('Falha ao gerar o log. O ticket **não** foi fechado (veja os logs do bot).'); }

      const names = t.files.map((f) => f.name);
      const sent = await sendTo(ids.ticketLogs, {
        ...out(card({
          color: colors.err, title: 'Ticket fechado',
          text: L(`**Ticket:** #${ch.name}`, `**Dono:** <@${ch.topic}>`, `**Fechado por:** ${i.user}`, `**Mensagens:** ${t.count}${t.truncated ? ' (limite do log)' : ''}`),
          images: t.kind === 'png' ? names.map((n) => `attachment://${n}`) : [],
          files: t.kind === 'txt' ? names.map((n) => `attachment://${n}`) : [],
        })),
        files: t.files,
      });
      if (!sent) return i.editReply('Não consegui enviar o log no canal de logs. O ticket **não** foi fechado (veja os logs do bot).');

      const rec = db.calls[ch.id];
      if (rec) { await i.guild.channels.delete(rec.voice).catch(() => {}); delete db.calls[ch.id]; save(); }
      setTimeout(() => ch.delete().catch(() => {}), 3000);
    },
  },
];
