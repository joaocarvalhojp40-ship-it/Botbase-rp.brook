// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Whitelist: 10 perguntas em 2 modais (9 de RP + 1 situação)
const { ButtonStyle } = require('discord.js');
const C = require('../../config');
const { ids, banners, colors } = C;
const { U, save } = require('../services/db');
const { btn, row, modal, answersOf, err, dm, sendTo, card, out, EPH } = require('../utils/ui');
const { L } = require('../utils/format');

const tmp = new Map(); // respostas da parte 1 (até o jogador enviar a parte 2)

module.exports = [
  {
    id: 'wl_start',
    run: async (i) => {
      const u = U(i.user.id);
      if (u.stage === 'wl_pending') return err(i, 'Sua whitelist já está em análise.');
      if (u.stage !== 'none') return err(i, 'Você já foi aprovado na whitelist.');
      return i.showModal(modal('wl1', 'Whitelist — Parte 1/2', C.questions.slice(0, 5).map((q, k) => ({ id: `q${k}`, label: q, long: true }))));
    },
  },
  {
    id: 'wl1',
    run: async (i) => {
      tmp.set(i.user.id, answersOf(i));
      return i.reply({ content: 'Parte 1 salva. Clique abaixo para continuar.', components: [row(btn('wl_next', 'Continuar (Parte 2)', ButtonStyle.Success))], flags: EPH });
    },
  },
  {
    id: 'wl_next',
    run: async (i) => {
      if (!tmp.has(i.user.id)) return err(i, 'Sessão expirada. Clique em Whitelist novamente.');
      const f = C.questions.slice(5).map((q, k) => ({ id: `q${k + 5}`, label: q, long: true }));
      f.push({ id: 'q9', label: C.situation.label, ph: C.situation.placeholder, long: true, max: 500 });
      return i.showModal(modal('wl2', 'Whitelist — Parte 2/2', f));
    },
  },
  {
    id: 'wl2',
    run: async (i) => {
      const u = U(i.user.id);
      const all = { ...tmp.get(i.user.id), ...answersOf(i) };
      tmp.delete(i.user.id);
      u.stage = 'wl_pending'; u.answers = all; save();
      const qs = [...C.questions, C.situation.label];
      const qa = qs.map((q, k) => `**${k + 1}. ${q}**\n${all[`q${k}`] || '—'}`).join('\n\n').slice(0, 3600);
      await sendTo(ids.wlLogs, out(card({ color: colors.warn, title: `Nova whitelist — ${i.user.username}`, text: L(`${i.user} (${i.user.id}) — use /aprove ou /reprove.`, '', qa) })));
      await dm(i.user, card({ color: colors.warn, title: 'Whitelist enviada', text: 'Recebemos suas respostas. Aguarde a análise da equipe — você será avisado por aqui.', image: banners.whitelist }));
      return i.reply({ content: 'Whitelist enviada. Acompanhe pela sua DM.', flags: EPH });
    },
  },
];
