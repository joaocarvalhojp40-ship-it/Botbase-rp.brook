// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { Client, GatewayIntentBits: G } = require('discord.js');

module.exports = new Client({ intents: [G.Guilds, G.GuildMessages, G.MessageContent] });
