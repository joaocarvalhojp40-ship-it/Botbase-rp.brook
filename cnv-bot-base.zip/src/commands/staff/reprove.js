// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { SlashCommandBuilder, PermissionFlagsBits: P } = require('discord.js');
const { user, str } = require('../../utils/options');
const { review } = require('../../services/review');

module.exports = {
  group: 'staff',
  data: new SlashCommandBuilder().setName('reprove').setDescription('Reprovar jogador (na etapa em que ele estiver)')
    .addUserOption(user('usuario', 'Jogador')).addStringOption(str('motivo', 'Motivo', false)).setDefaultMemberPermissions(P.ViewAuditLog),
  run: (i) => review(i, false),
};
