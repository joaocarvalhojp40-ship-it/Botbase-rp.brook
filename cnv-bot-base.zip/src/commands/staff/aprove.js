// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { SlashCommandBuilder, PermissionFlagsBits: P } = require('discord.js');
const { user } = require('../../utils/options');
const { review } = require('../../services/review');

module.exports = {
  group: 'staff',
  data: new SlashCommandBuilder().setName('aprove').setDescription('Aprovar jogador (na etapa em que ele estiver)')
    .addUserOption(user('usuario', 'Jogador')).setDefaultMemberPermissions(P.ViewAuditLog),
  run: (i) => review(i, true),
};
