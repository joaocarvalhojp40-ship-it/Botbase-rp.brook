// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { SlashCommandBuilder } = require('discord.js');
const { str } = require('../../utils/options');
const { db } = require('../../services/db');
const bank = require('../../services/bank');
const { isBanker } = require('../../utils/perms');
const { err, out } = require('../../utils/ui');
const { money, ts } = require('../../utils/format');

// /comprovante id:<ID> — mostra as informações de uma transação (envolvidos e banqueiros)
module.exports = {
  group: 'bank',
  data: new SlashCommandBuilder().setName('comprovante').setDescription('Ver as informações de uma transferência pelo ID do comprovante')
    .addStringOption(str('id', 'ID do comprovante (ex: rppaymnts8584118)')),
  async run(i) {
    const id = i.options.getString('id').trim().toLowerCase();
    const tx = db.tx[id];
    if (!tx) return err(i, 'Comprovante não encontrado. Confira o ID.');
    if (!isBanker(i) && ![tx.from, tx.to, tx.by].includes(i.user.id)) return err(i, 'Você não tem acesso a esse comprovante.');
    const who = (v) => (v ? `<@${v}>` : '—');
    return i.reply(out(bank.receiptCard('COMPROVANTE', [
      bank.k('ID', `\`${tx.id}\``), bank.k('Tipo', bank.TYPES[tx.type] || tx.type), '',
      bank.k('Efetuado por', who(tx.from)), bank.k('Destinado para', who(tx.to)),
      bank.k('Valor', money(tx.value)), tx.reason ? bank.k('Motivo', tx.reason) : false,
      bank.k('Autorizado por', who(tx.by)), bank.k('Data', ts(tx.at)),
    ].filter((x) => x !== false))));
  },
};
