// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { SlashCommandBuilder } = require('discord.js');
const { user } = require('../../utils/options');
const { U } = require('../../services/db');
const bank = require('../../services/bank');
const { isBanker } = require('../../utils/perms');
const { err, out } = require('../../utils/ui');
const { money } = require('../../utils/format');

module.exports = {
  group: 'bank',
  data: new SlashCommandBuilder().setName('saldo').setDescription('Ver saldo (banqueiro pode ver o de qualquer jogador)')
    .addUserOption(user('usuario', 'Jogador (apenas banqueiro)', false)),
  async run(i) {
    const target = i.options.getUser('usuario') || i.user;
    if (target.id !== i.user.id && !isBanker(i)) return err(i, 'Apenas **banqueiros** podem ver o saldo de outros jogadores.');
    const u = U(target.id);
    return i.reply(out(bank.receiptCard('SALDO', [bank.k('Titular', `${target}`), '', bank.k('Banco', money(u.bank)), bank.k('Carteira', money(u.cash))])));
  },
};
