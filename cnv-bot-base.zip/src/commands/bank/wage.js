// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { SlashCommandBuilder } = require('discord.js');
const C = require('../../../config');
const { user, int } = require('../../utils/options');
const { U } = require('../../services/db');
const bank = require('../../services/bank');
const { out } = require('../../utils/ui');
const { money } = require('../../utils/format');

module.exports = {
  group: 'bank', banker: true,
  data: new SlashCommandBuilder().setName('wage').setDescription('[Banqueiro] Pagar salário')
    .addUserOption(user('usuario', 'Jogador'))
    .addIntegerOption(int('salario', 'Valor do salário', C.money.min, C.money.max)),
  async run(i) {
    const t = i.options.getUser('usuario'), v = i.options.getInteger('salario');
    U(t.id).bank += v;
    const tx = bank.record({ type: 'wage', from: null, to: t.id, value: v, by: i.user.id });
    return i.reply(out(bank.receiptCard('SALÁRIO', [bank.k('Funcionário', `${t}`), '', bank.k('Valor', money(v)), bank.receiptLine(tx)])));
  },
};
