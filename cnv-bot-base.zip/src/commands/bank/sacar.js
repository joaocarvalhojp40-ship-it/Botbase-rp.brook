// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { SlashCommandBuilder } = require('discord.js');
const { value } = require('../../utils/options');
const { U } = require('../../services/db');
const bank = require('../../services/bank');
const { err, out } = require('../../utils/ui');
const { money } = require('../../utils/format');

module.exports = {
  group: 'bank',
  data: new SlashCommandBuilder().setName('sacar').setDescription('Sacar dinheiro do banco para a carteira').addIntegerOption(value),
  async run(i) {
    const v = i.options.getInteger('valor'), me = U(i.user.id);
    if (me.bank < v) return err(i, `Saldo insuficiente. Seu saldo no banco: ${money(me.bank)}.`);
    me.bank -= v; me.cash += v;
    const tx = bank.record({ type: 'withdraw', from: i.user.id, to: i.user.id, value: v, by: i.user.id });
    return i.reply(out(bank.receiptCard('SAQUE', [bank.k('Titular', `${i.user}`), '', bank.k('Valor', money(v)), bank.receiptLine(tx)])));
  },
};
