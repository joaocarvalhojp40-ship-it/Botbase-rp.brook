// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { SlashCommandBuilder } = require('discord.js');
const { user, value } = require('../../utils/options');
const { U } = require('../../services/db');
const bank = require('../../services/bank');
const { err, out } = require('../../utils/ui');
const { money } = require('../../utils/format');

module.exports = {
  group: 'bank',
  data: new SlashCommandBuilder().setName('enviar').setDescription('Enviar dinheiro do banco a outro jogador')
    .addUserOption(user('usuario', 'Destinatário')).addIntegerOption(value),
  async run(i) {
    const to = i.options.getUser('usuario'), v = i.options.getInteger('valor'), me = U(i.user.id);
    if (to.bot || to.id === i.user.id) return err(i, 'Destinatário inválido.');
    if (me.bank < v) return err(i, `Saldo insuficiente. Seu saldo no banco: ${money(me.bank)}.`);
    me.bank -= v; U(to.id).bank += v;
    const tx = bank.record({ type: 'payment', from: i.user.id, to: to.id, value: v, by: i.user.id });
    return i.reply(out(bank.paymentCard(tx)));
  },
};
