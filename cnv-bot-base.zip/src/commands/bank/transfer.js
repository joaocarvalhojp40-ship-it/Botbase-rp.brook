// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { SlashCommandBuilder } = require('discord.js');
const { user, value } = require('../../utils/options');
const { U } = require('../../services/db');
const bank = require('../../services/bank');
const { err, out } = require('../../utils/ui');
const { money } = require('../../utils/format');

module.exports = {
  group: 'bank', banker: true,
  data: new SlashCommandBuilder().setName('transfer').setDescription('[Banqueiro] Transferir valor entre jogadores')
    .addUserOption(user('solicitante', 'Usuário solicitante (quem envia)'))
    .addUserOption(user('destinatario', 'Usuário que receberá o valor'))
    .addIntegerOption(value),
  async run(i) {
    const from = i.options.getUser('solicitante'), to = i.options.getUser('destinatario'), v = i.options.getInteger('valor');
    if (from.bot || to.bot || from.id === to.id) return err(i, 'Usuários inválidos.');
    if (U(from.id).bank < v) return err(i, `${from.username} não tem saldo suficiente (${money(U(from.id).bank)}).`);
    U(from.id).bank -= v; U(to.id).bank += v;
    const tx = bank.record({ type: 'payment', from: from.id, to: to.id, value: v, by: i.user.id });
    return i.reply(out(bank.paymentCard(tx)));
  },
};
