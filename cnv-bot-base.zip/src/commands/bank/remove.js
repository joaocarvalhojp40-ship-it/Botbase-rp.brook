// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { SlashCommandBuilder } = require('discord.js');
const { user, str, int } = require('../../utils/options');
const { U } = require('../../services/db');
const bank = require('../../services/bank');
const { out } = require('../../utils/ui');
const { money } = require('../../utils/format');

module.exports = {
  group: 'bank', banker: true,
  data: new SlashCommandBuilder().setName('remove').setDescription('[Banqueiro] Remover dinheiro do banco de um jogador')
    .addUserOption(user('usuario', 'Jogador'))
    .addIntegerOption(int('quantidade', 'Quantidade a remover', 1))
    .addStringOption(str('motivo', 'Motivo')),
  async run(i) {
    const t = i.options.getUser('usuario'), q = i.options.getInteger('quantidade'), reason = i.options.getString('motivo');
    const u = U(t.id), taken = Math.min(u.bank, q);
    u.bank -= taken;
    const tx = bank.record({ type: 'remove', from: t.id, to: null, value: taken, reason, by: i.user.id });
    return i.reply(out(bank.receiptCard('REMOÇÃO', [
      bank.k('Jogador', `${t}`), '',
      bank.k('Valor', `${money(taken)}${taken < q ? ' (saldo insuficiente)' : ''}`),
      bank.k('Motivo', reason), bank.receiptLine(tx),
    ])));
  },
};
