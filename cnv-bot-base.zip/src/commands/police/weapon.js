// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { SlashCommandBuilder } = require('discord.js');
const C = require('../../../config');
const { user } = require('../../utils/options');
const police = require('../../services/police');
const { L } = require('../../utils/format');

module.exports = {
  group: 'police',
  data: new SlashCommandBuilder().setName('carrying-a-weapon').setDescription('[Polícia] Conceder porte de arma')
    .addUserOption(user('usuario', 'Jogador'))
    .addStringOption((o) => o.setName('tipo').setDescription('Tipo de porte').setRequired(true).addChoices(...C.weaponTypes.map((t) => ({ name: t, value: t })))),
  async run(i) {
    const t = i.options.getUser('usuario');
    await police.log(i, 'Porte de arma', L(`**Portador:** ${t}`, `**Tipo de porte:** ${i.options.getString('tipo')}`, `**Policial:** ${i.user}`));
  },
};
