// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { SlashCommandBuilder } = require('discord.js');
const { user, str, int } = require('../../utils/options');
const police = require('../../services/police');
const { L } = require('../../utils/format');

module.exports = {
  group: 'police',
  data: new SlashCommandBuilder().setName('prison').setDescription('[Polícia] Prender um jogador')
    .addUserOption(user('usuario', 'Usuário preso'))
    .addStringOption(str('lei', 'Lei infringida'))
    .addIntegerOption(int('tempo', 'Tempo de prisão (minutos)', 1)),
  async run(i) {
    const t = i.options.getUser('usuario');
    await police.log(i, 'Prisão', L(`**Preso:** ${t}`, `**Lei:** ${i.options.getString('lei')}`, `**Tempo:** ${i.options.getInteger('tempo')} minuto(s)`, `**Policial:** ${i.user}`));
  },
};
