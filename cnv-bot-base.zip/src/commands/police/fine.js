// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { SlashCommandBuilder } = require('discord.js');
const { user, str, int } = require('../../utils/options');
const { U } = require('../../services/db');
const bank = require('../../services/bank');
const police = require('../../services/police');
const { L, money } = require('../../utils/format');

module.exports = {
  group: 'police',
  data: new SlashCommandBuilder().setName('fine').setDescription('[Polícia] Multar um jogador')
    .addUserOption(user('usuario', 'Usuário multado'))
    .addStringOption(str('lei', 'Lei infringida'))
    .addIntegerOption(int('valor', 'Valor da multa', 1)),
  async run(i) {
    const t = i.options.getUser('usuario'), law = i.options.getString('lei'), v = i.options.getInteger('valor');
    const u = U(t.id), charge = Math.min(u.bank, v), id = bank.newId();
    const sent = await police.log(i, 'Multa', L(
      `**Multado:** ${t}`, `**Lei:** ${law}`,
      `**Valor:** ${money(v)}${charge < v ? ` (cobrado ${money(charge)} — saldo insuficiente)` : ''}`,
      `**Policial:** ${i.user}`, `**Comprovante:** \`${id}\``));
    if (!sent) return;
    u.bank -= charge;
    bank.record({ id, type: 'fine', from: t.id, to: null, value: charge, reason: law, by: i.user.id });
  },
};
