// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// Carrega automaticamente comandos, interações, comandos de prefixo e eventos.
const fs = require('fs');
const path = require('path');

const walk = (dir) =>
  fs.readdirSync(dir, { withFileTypes: true }).flatMap((d) =>
    d.isDirectory() ? walk(path.join(dir, d.name)) : d.name.endsWith('.js') ? [path.join(dir, d.name)] : []);

module.exports = (client) => {
  client.commands = new Map();     // slash commands  → src/commands/**
  client.interactions = new Map(); // botões/modais/selects (por customId) → src/interactions/*
  client.prefixCmds = new Map();   // $$comandos → src/prefix/*

  for (const f of walk(path.join(__dirname, 'commands'))) {
    const c = require(f);
    client.commands.set(c.data.name, c);
  }
  for (const f of walk(path.join(__dirname, 'interactions'))) {
    for (const h of [].concat(require(f))) client.interactions.set(h.id, h);
  }
  for (const f of walk(path.join(__dirname, 'prefix'))) {
    const p = require(f);
    client.prefixCmds.set(p.name, p);
  }
  for (const f of walk(path.join(__dirname, 'events'))) {
    const e = require(f);
    client[e.once ? 'once' : 'on'](e.name, (...args) => Promise.resolve(e.run(...args)).catch((err) => console.error(`Erro no evento ${e.name}:`, err)));
  }
  console.log(`📂 ${client.commands.size} comandos, ${client.interactions.size} interações, ${client.prefixCmds.size} comandos de prefixo.`);
};
