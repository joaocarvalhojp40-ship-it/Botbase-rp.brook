// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// $$rp — "Roleplay ON" + link do servidor privado do Brookhaven (exige Gerenciar Servidor)
const { PermissionFlagsBits: P } = require('discord.js');
const C = require('../../config');
const { card, out, linkBtn, row } = require('../utils/ui');
const { L } = require('../utils/format');

module.exports = {
  name: 'rp',
  allow: (member) => member.permissions.has(P.ManageGuild),
  async run(m) {
    const link = C.rp.privateServerLink;
    if (!/^https?:\/\//.test(link)) {
      console.error('❌ BUG/CONFIG: defina rp.privateServerLink em config/settings.js (link do servidor privado do Brookhaven).');
      return m.reply('Configure o link do servidor privado em `config/settings.js` (`rp.privateServerLink`).').catch(() => {});
    }
    await m.channel.send(out(card({
      title: 'Roleplay ON',
      text: L(`O servidor privado de ${C.rp.gameName} está aberto.`, 'Entre pelo botão abaixo e siga as regras do RP.', '', `Aberto por ${m.author}`),
      rows: row(linkBtn('Entrar no servidor', link)),
    })));
    m.delete().catch(() => {});
  },
};
