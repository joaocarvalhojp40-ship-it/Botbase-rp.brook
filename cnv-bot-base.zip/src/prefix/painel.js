// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// $$painel — painel de Whitelist e Allowhitelist (canal configurado em ids.wlPanel)
const C = require('../../config');
const { isMod } = require('../utils/perms');
const { card, out, btn, row, sendTo } = require('../utils/ui');
const { L } = require('../utils/format');

module.exports = {
  name: 'painel',
  allow: isMod,
  async run(m) {
    await sendTo(C.ids.wlPanel, out(card({
      title: 'Whitelist e Allowhitelist', image: C.banners.whitelist,
      text: L(
        `**Whitelist:** responda as perguntas de Roleplay (${C.questions.length} básicas + 1 situação).`,
        `**Allowhitelist:** crie seu personagem (mínimo ${C.minAge} anos) — nome, idade, nacionalidade, raça e usuário do Roblox.`,
        '', 'Você será avisado por DM a cada etapa.'),
      rows: row(btn('wl_start', 'Whitelist', undefined, 'whitelist'), btn('al_start', 'Criar personagem', undefined, 'character')),
    })));
    m.delete().catch(() => {});
  },
};
