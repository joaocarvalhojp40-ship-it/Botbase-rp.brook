// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
// $$up — painel de suporte (botão de abrir ticket)
const C = require('../../config');
const { isMod } = require('../utils/perms');
const { card, out, btn, row } = require('../utils/ui');
const { L } = require('../utils/format');

module.exports = {
  name: 'up',
  allow: isMod,
  async run(m) {
    await m.channel.send(out(card({
      title: `Suporte - ${C.serverName}`, image: C.banners.support,
      text: L('Precisa de ajuda? Abra um ticket pelo botão abaixo.', '', `Cooldown de ${C.ticketCooldownMin} minutos entre tickets. Apenas 1 ticket por usuário.`),
      rows: row(btn('ticket_open', 'Abrir ticket', undefined, 'ticket')),
    })));
    m.delete().catch(() => {});
  },
};
