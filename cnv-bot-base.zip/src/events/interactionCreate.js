// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { Events } = require('discord.js');
const { ids } = require('../../config');
const C = require('../../config');
const { has, isBanker } = require('../utils/perms');
const { err } = require('../utils/ui');

// Regras de acesso por grupo de comando
async function guard(i, cmd) {
  if (cmd.group === 'bank') {
    if (i.channelId !== ids.bankChannel) return err(i, `Este comando só pode ser usado em <#${ids.bankChannel}>.`), false;
    const banker = isBanker(i);
    if (cmd.banker && !banker) return err(i, 'Apenas **banqueiros** podem usar este comando.'), false;
    if (!cmd.banker && !banker && C.requireApprovedForBank && !has(i, ids.roleAprovado)) return err(i, 'Você precisa ter um personagem aprovado.'), false;
  }
  if (cmd.group === 'police' && !has(i, ids.police)) return err(i, 'Apenas **policiais** podem usar este comando.'), false;
  return true;
}

module.exports = {
  name: Events.InteractionCreate,
  async run(i) {
    try {
      if (i.isChatInputCommand()) {
        const cmd = i.client.commands.get(i.commandName);
        if (!cmd || !(await guard(i, cmd))) return;
        return await cmd.run(i);
      }
      if (i.isButton() || i.isModalSubmit() || i.isAnySelectMenu()) {
        const h = i.client.interactions.get(i.customId);
        if (h) return await h.run(i);
      }
    } catch (e) {
      console.error(e);
      err(i, 'Ocorreu um erro interno.').catch(() => {});
    }
  },
};
