// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { Events } = require('discord.js');
const C = require('../../config');

module.exports = {
  name: Events.MessageCreate,
  async run(m) {
    if (m.author.bot || !m.guild || !m.member || !m.content.startsWith(C.prefix)) return;
    const name = m.content.slice(C.prefix.length).trim().split(/\s+/)[0].toLowerCase();
    const cmd = m.client.prefixCmds.get(name);
    if (!cmd || !cmd.allow(m.member)) return;
    await cmd.run(m);
  },
};
