// CNV Bot Base — © eljoaogg · Hyper Squad. Uso sujeito à LICENSE; não remova os créditos.
const { Events, ActivityType, REST, Routes } = require('discord.js');
const C = require('../../config');
const { ensureInvite } = require('../services/invite');
const { checkConfig } = require('../services/checkConfig');
const { applyBio } = require('../services/credits');

module.exports = {
  name: Events.ClientReady,
  once: true,
  async run(client) {
    console.log(`✅ ${client.user.tag} online.`);

    checkConfig(); // avisa IDs não preenchidos

    // 1) Registra os slash commands no servidor
    if (!/^\d{17,20}$/.test(C.guildId)) console.error('❌ BUG/CONFIG: guildId inválido em config/settings.js.');
    else {
      try {
        const body = [...client.commands.values()].map((c) => c.data.toJSON());
        await new REST().setToken(client.token).put(Routes.applicationGuildCommands(client.user.id, C.guildId), { body });
        console.log(`✅ ${body.length} comandos registrados.`);
      } catch (e) {
        console.error('❌ Falha ao registrar comandos:', e.status, e.message);
        if (e.status === 403 || e.code === 50001) console.error('→ O bot não está nesse servidor ou foi convidado sem o escopo "applications.commands".');
      }
    }

    // 2) Convite permanente + status "Jogando <seu roleplay> | discord.gg/..."
    const invite = await ensureInvite(client);
    const link = invite && C.presence.showInvite ? ` | ${invite.replace('https://', '')}` : '';
    client.user.setPresence({ activities: [{ name: `${C.presence.text}${link}`, type: ActivityType.Playing }], status: 'online' });
    if (invite) console.log(`🔗 Convite permanente: ${invite}`);

    // 3) Crédito obrigatório na biografia do bot (LICENSE)
    await applyBio(client);
  },
};
